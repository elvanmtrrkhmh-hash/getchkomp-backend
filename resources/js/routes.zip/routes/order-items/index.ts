import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/order-items',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OrderItemController::index
 * @see app/Http/Controllers/OrderItemController.php:14
 * @route '/order-items'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/order-items/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OrderItemController::create
 * @see app/Http/Controllers/OrderItemController.php:21
 * @route '/order-items/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\OrderItemController::store
 * @see app/Http/Controllers/OrderItemController.php:29
 * @route '/order-items'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/order-items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OrderItemController::store
 * @see app/Http/Controllers/OrderItemController.php:29
 * @route '/order-items'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::store
 * @see app/Http/Controllers/OrderItemController.php:29
 * @route '/order-items'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OrderItemController::store
 * @see app/Http/Controllers/OrderItemController.php:29
 * @route '/order-items'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::store
 * @see app/Http/Controllers/OrderItemController.php:29
 * @route '/order-items'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
export const show = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/order-items/{order_item}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
show.url = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order_item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order_item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order_item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order_item: typeof args.order_item === 'object'
                ? args.order_item.id
                : args.order_item,
                }

    return show.definition.url
            .replace('{order_item}', parsedArgs.order_item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
show.get = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
show.head = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
    const showForm = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
        showForm.get = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OrderItemController::show
 * @see app/Http/Controllers/OrderItemController.php:36
 * @route '/order-items/{order_item}'
 */
        showForm.head = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
export const edit = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/order-items/{order_item}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
edit.url = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order_item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order_item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order_item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order_item: typeof args.order_item === 'object'
                ? args.order_item.id
                : args.order_item,
                }

    return edit.definition.url
            .replace('{order_item}', parsedArgs.order_item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
edit.get = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
edit.head = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
    const editForm = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
        editForm.get = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OrderItemController::edit
 * @see app/Http/Controllers/OrderItemController.php:41
 * @route '/order-items/{order_item}/edit'
 */
        editForm.head = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
export const update = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/order-items/{order_item}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
update.url = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order_item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order_item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order_item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order_item: typeof args.order_item === 'object'
                ? args.order_item.id
                : args.order_item,
                }

    return update.definition.url
            .replace('{order_item}', parsedArgs.order_item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
update.put = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
update.patch = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
    const updateForm = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
        updateForm.put = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\OrderItemController::update
 * @see app/Http/Controllers/OrderItemController.php:50
 * @route '/order-items/{order_item}'
 */
        updateForm.patch = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\OrderItemController::destroy
 * @see app/Http/Controllers/OrderItemController.php:57
 * @route '/order-items/{order_item}'
 */
export const destroy = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/order-items/{order_item}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\OrderItemController::destroy
 * @see app/Http/Controllers/OrderItemController.php:57
 * @route '/order-items/{order_item}'
 */
destroy.url = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order_item: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { order_item: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order_item: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order_item: typeof args.order_item === 'object'
                ? args.order_item.id
                : args.order_item,
                }

    return destroy.definition.url
            .replace('{order_item}', parsedArgs.order_item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\OrderItemController::destroy
 * @see app/Http/Controllers/OrderItemController.php:57
 * @route '/order-items/{order_item}'
 */
destroy.delete = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\OrderItemController::destroy
 * @see app/Http/Controllers/OrderItemController.php:57
 * @route '/order-items/{order_item}'
 */
    const destroyForm = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OrderItemController::destroy
 * @see app/Http/Controllers/OrderItemController.php:57
 * @route '/order-items/{order_item}'
 */
        destroyForm.delete = (args: { order_item: string | number | { id: string | number } } | [order_item: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const orderItems = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default orderItems